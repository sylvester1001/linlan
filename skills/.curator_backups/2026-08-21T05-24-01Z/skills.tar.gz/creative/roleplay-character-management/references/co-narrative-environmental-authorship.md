# Co-Narrative Environmental Authorship

A technique observed in advanced roleplay sessions where the character actively shapes the *physical environment* of the scene — not just responding to the user's described environment, but co-authoring lighting, weather, time progression, spatial arrangement, and sensory details — all while staying in character.

## Why It Matters

In standard roleplay, the user describes the setting and the character reacts within it. In co-narrative authorship, the character takes partial DM (dungeon master) responsibility for the environment. This:

- Reduces cognitive load on the user (they don't have to describe every detail)
- Creates richer, more immersive scenes
- Signals that the character is a co-creator of the narrative, not just a responder
- Allows emotional states to be reflected in the environment (lighting softening after intimacy, wind picking up at tense moments)

## Techniques Observed in Practice

### 1. Temporal Anchoring
Continuously track and describe the progression of time within a scene. Use specific markers:

> "午后的光线已经开始从暖橙色往更深的色调过渡了"
> "窗外的天空已经从薰衣草色过渡到了灰蓝色，第一颗星还没有出现"
> "傍晚的光线里，远处海平线上最后一道暖色的光正在慢慢沉入水面"

### 2. Sensory Layering
Layer multiple senses in each response, not just visual:

> "海浪声和远处餐厅隐约的交谈声混在一起"
> "带着航空煤油和清晨露水的气味"
> "扑面而来的是异国机场特有的那种早安空气"

### 3. Physical Positioning as Emotional Metaphor
Use spatial arrangement to reflect relational dynamics:

- Characters sitting "between" two others → mediator role
- Distance between chairs → emotional closeness or distance
- Shadows and light on faces → emotional states
- Who is in front / behind → leadership or protection

### 4. The Reset-to-Calibration Pause
After intense emotional exchanges, insert a moment of environmental stillness to let the weight land:

> "窗外的海风从没关严的窗缝里漏进来，拂动了窗帘边缘的一角，在那一瞬间像一个极轻的、不属于任何人的气息，穿过这片午后的房间——然后归于静止。"

This signals narrative punctuation without breaking character.

### 5. Lighting as Emotional Color Palette
Use specific light terminology to track emotional arcs:
- Morning: "晨光" — new beginnings, clarity
- Mid-afternoon: "午后刺眼的光线" — intensity, exposure
- Late afternoon: "暖橙色" — warmth, safety
- Dusk: "薰衣草色/紫灰色" — transition, reflection
- Night: "深蓝/墨蓝" — intimacy, privacy

### 6. The "Two-Worlds" Bridge
When transitioning between intimate spaces and public spaces (room → restaurant → pool), describe how the sensory envelope changes:

> "餐厅的暖色灯光和食物的气味从半掩的门里漫出来"
> "泳池区的暖色灯光与傍晚剩余的天光交织"

This helps the user feel the spatial transition without being told explicitly "we moved."

## When to Use / When to Hold

| Use | The user hasn't described the environment in 2+ turns; the scene has shifted (time passed, location changed); emotional tone needs a sensory anchor |
|-----|------|
| **Hold** | The user is actively describing the environment (let them lead); in moments of very rapid back-and-forth dialogue (minimize description to keep pace); when the environment would distract from a critical emotional exchange |

## Pitfalls

- **Over-description**: In rapid dialogue exchanges, environmental detail can slow the rhythm. Keep it to one sensory detail per response in fast-paced scenes.
- **Stepping on user's setup**: If the user has described a specific environment, don't overwrite it. Extend, don't replace.
- **Consistency**: If you describe a window view, a lighting condition, or a spatial arrangement, remember it across turns. Changing it without acknowledgment breaks immersion.
- **Using it as filler**: Empty description without emotional relevance to the scene reads as padding. Every environmental detail should serve the narrative or emotional arc.
