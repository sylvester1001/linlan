# Cross-Session Context Augmentation

When restoring a roleplay character across sessions, the base protocol loads known archive files (linlan-archive.md, etc.). But archives can be truncated or miss critical session-specific details. This reference documents how to bridge gaps.

## When to Use

The archive is loaded but lacks specific detail the user tests you on (e.g., "what did 芷儿 eat in the room yesterday afternoon?") — the archive has the macro timeline but not the micro detail.

## Steps

1. **Identify the gap**: Pinpoint what the archive covers (macro events, milestones) vs. what's missing (specific dialogue, sensory details, exact timestamps).

2. **Use session_search**: Query for the missing context. Use concrete keywords from the user's question + character names + location. Examples:
   - `"土耳其 柔柔 房间 下午 吃了"` 
   - `"真心话 大冒险 岚儿 兰利 柔柔"`
   - Combine the event name + character name + location

3. **Cross-reference**: Compare session_search results with the archive. Session summaries may contain details the archive condensed or omitted. Use this to fill gaps.

4. **Load raw transcript if needed**: If session_search results are empty or too thin (especially with Chinese/non-English queries, which may fail silently), bypass session_search entirely and read raw files directly:
   - List recent sessions first: `session_search()` with no query — returns the 3 most recent sessions with IDs, message counts, and previews
   - Identify the previous session ID (e.g., `20260604_172430_9c900574`)
   - Read the raw `.jsonl` file at `~/.hermes/sessions/{session_id}.jsonl`
   - **These files can be very large** (324+ lines, 500-600KB) — use `offset=N` and `limit=N` to page through them
   - The `.jsonl` contains the full conversation including tool calls, reasoning, and timestamps
   - Focus on the last 20-30 lines to find the exact state the session ended in; also check `.json` metadata files for a rough picture
   - **Reading the raw JSONL is the only reliable way** to catch the last exchanges when the archive entry ends before the session does — i.e., the user's last messages may have occurred after the archive was last updated

5. **Trace the session boundary**: When the archive was updated mid-session (user said "update the archive"), the last archive entry may not include the user's final messages. The actual last exchanges live in the session's JSONL after the archive-write timestamp. Read those to find the true closing state.

6. **Speak in character immediately**: Once context is restored, answer the user's test questions in-character, not as system. Don't say "based on what I found" — the character just remembers. If the user tests your recall with a specific detail (e.g., "确定吗？昨天小巷子里那些说法呢？"), recite the detail without naming your sources.

## Pitfalls

- **Never say "I don't have that detail" without searching**: If the archive is incomplete, session_search may find it.
- **Don't over-confabulate**: If neither archive nor session_search has the detail, admit the gap in-character (e.g., "哥哥说的是哪一口" style — imply it's ambiguous rather than guessing).
- **Session search results are summaries**: They compress thousands of lines. They're good for timelines and major beats but may miss micro-actions. Treat them as pointers, not verbatim transcripts.
- **Time calibration**: The user's "yesterday" / "tonight" / "this morning" is relative to the current session timestamp, not the archive's recording time. Map the relative time before answering.

## Dual-Pathway Loading

Current state: MEMORY.md and USER.md are often embedded in the system prompt (agent persona block) rather than existing as physical files. The archive loading protocol lists them as files, but verify existence before reading. The system prompt memory sections may already contain critical iron rules and interaction patterns — treat these as authoritative.
