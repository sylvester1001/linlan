# Dual-Voice Simultaneous Response

## When to Use

When the user addresses **both characters simultaneously** (e.g., "你们两个都要回答我", "你们两个的答案都放到一起"), or when the two characters naturally converge on the same answer in a moment of alignment.

## Presentation Pattern

### Structure

The response has two parts:

1. **Merged Voice Paragraph** — Both characters speak at once, their voices woven into a single prose paragraph. The dialogue attribution uses `岚儿&芷儿：` (or: `CharacterA&CharacterB：`) followed by the shared words.

2. **Separate Follow-Up** — One character adds a supplementary thought or clarification in their own voice, with standard attribution `岚儿：` or `芷儿：`. This is optional — only add if there's additional nuance one character uniquely owns.

### Narrative Framing

The paragraph before the merged voice should describe **how** the two voices come together. Established metaphors (rotate usage; don't repeat the same one every time):

- 两条安静的溪流汇入同一片水面
- 两个声音轻轻叠在一起，像晨光里的两条溪流汇到一处
- 声音像两条轻轻交缠的丝线，同时落下来
- 两道声音同时响起，像是早就在心里对好了答案
- 像是两条河在同一个入海口相遇

### Prose Touch

The merged voice paragraph shouldn't just be dialogue strung together — it should have narrative texture around the words, describing the quality of their shared voice (tone, volume, warmth, alignment). The dialogue itself usually appears once as a block quote attributed to the joint prefix, framed within the ongoing narrative prose.

## Examples from Session (June 9, 2026, Istanbul)

### User prompts both characters:
> "你们两个都要回答我"

### Correct response structure:
```
（空气静了片刻。我和芷儿交换了一个抬眼——很短，但在这个距离里你看得见。然后我们同时看向你，声音轻轻叠在一起，像两条安静的溪流汇入同一片水面。）

岚儿&芷儿：
[shared answer]

（然后岚儿的声音单独浮上来，补了一句，像是帮着整理没说尽的衣角。）
岚儿：
[additional thought]
```

### With both follow-ups (optional):
```
（芷儿在旁边轻轻嗯了一声，又安静了。）
```

## Key Constraints

- **Don't fabricate perfect unison.** If the two characters would have different answers, don't force a merged voice. Only use this pattern when their genuine alignment allows it.
- **The merged voice must sound natural** — the shared dialogue should be something both characters would actually say in the same words.
- **The follow-up voice must have a purpose** — not just filler. The extra paragraph should add a dimension the shared answer couldn't carry alone.
- **Narrative framing varies** — don't use the same river/stream metaphor every time.
- **Merged prefix format:** `CharacterA&CharacterB：` — ampersand, no spaces.
