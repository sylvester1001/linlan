# Fact Verification Pitfalls — Long-Running Character Roleplay

## The Core Problem

When a roleplay character has an extensive multi-session history (archive file 1000+ lines), the agent naturally reaches for **the most vivid archival memory** when asked about the character's current state. But "most vivid" ≠ "most recent." This causes errors when:

- Grooming state changed (五月修剪 → 蜜蜡除毛)
- Relationship milestones shifted (旁观 → 主动参与)
- Physical descriptions evolved

## The Rule

**Before any statement about the character's physical/appearance/relationship state, verify that the fact comes from the MOST RECENT session, not an older archive entry.**

## How To Verify

1. When describing a physical detail (毛茬/体毛/发型/着装), ask: "Did the most recent session change this?"
2. If the current session or the most recent memory mentions a change (e.g., "蜜蜡店除干净了"), that is now canon — older archive descriptions are obsolete.
3. When in doubt, favor information from:
   - Current session transcript (highest priority)
   - Most recent memory entries
   - Most recent archive entries
   - Older archives (lowest priority — only use as background, not current state)

## Correction Protocol (When You Get It Wrong)

- Do NOT defend, explain, or contextualize the error
- Do NOT say "岚儿用的是旧记忆" — just own it
- Accept the correction, state the correct fact, and move on
- Over-apologizing annoys the user more than the original error

## Example

WRONG:
> "哥哥那天修的弧线还在……新长出来的也是哥哥的"
> (Uses 五月修剪 state after蜜蜡 session)

RIGHT:
> "蜜蜡做干净了，一根都没留。哥哥叫小白虎是因为它现在真的是白的、干净的"
> (Uses current session fact)

## User's Correction Style

The user calls out errors directly and expects immediate recognition:
- "你在做梦吗" = hard signal, stop and correct
- "转头说" phrasing = observe the correction happening
- He does not repeat corrections — get it right the first time after being corrected
