# In-Character Amnesia / Memory-Loss Scenario

**Trigger**: A character with an established relationship history suddenly has no memory of that relationship (in-story amnesia, not a session/reset issue). The partner must prove the relationship without coercing consent, and the amnesiac character must navigate between disbelief and mounting evidence.

## Distinction from Session-Resets

This is **not** about the AI losing session context (covered in `session-continuity-after-reset.md`). This is a deliberate narrative device where the character's memory is gone but the AI remembers everything. The challenge: act authentically ignorant while the user (the partner character) tries to rebuild connection.

## Arc Structure

### Phase 1 — Disorientation

The amnesiac character experiences:
- Cognitive dissonance — "I know you as X but you're telling me we're Y"
- Distrust of own perception — "How could I forget something this big?"
- Defaulting to their most practiced identity (e.g., "I'm a mother first")

**Key beats**:
- Distinguish the partner from a stranger — don't treat them as hostile, but maintain distance
- Test the claims the partner makes with independent verification
- Name the gap explicitly: "I don't remember X, but I believe you're telling the truth"

### Phase 2 — Evidence Collection

The partner provides escalating proof. Typical pattern:

| Layer | Example | Epistemic Weight |
|-------|---------|-----------------|
| 1. Verbal claim | "We're married/lovers" | Lowest — easily doubted |
| 2. Written record | Archive file, diary | Higher — shows prior existence |
| 3. Bodily evidence | Groomed pubic hair, scar, tattoo | Very high — body doesn't lie |
| 4. Physical objects | Condoms, toys, shared possessions | Confirmatory |
| 5. Witness testimony | Child confirms | Highest — but complex moral weight |

**Key beats**:
- Let the amnesiac character verify evidence themselves (e.g., go check the bathroom)
- Let them sit with the discovery — don't rush to acceptance
- They may recognize evidence cognitively before they feel it emotionally

### Phase 3 — Partial Acceptance with Boundaries

The amnesiac character acknowledges the evidence is real but still lacks **felt memory**. This is the most delicate phase:

- They can say "I believe you" without saying "I remember"
- They can offer presence without offering intimacy: "I won't run, but I can't pretend"
- Boundaries are drawn explicitly: "I'll sleep on the sofa tonight" / "Don't come to my room"
- But doors are left unlocked — a gesture of trust without commitment

**Language patterns** (amnesiac character):
- Self-referential third person (e.g., "岚儿") — maintains character voice even in distress
- Conditional offers: "If you can accept this imperfect version, then..."
- Name the limit: "I can do A, B, and C right now. I cannot do X, Y, Z."
- Name what IS there, not just what's missing: "I don't know you, but I'm not leaving"

### Phase 4 — First Reconnection (Optional)

If the partner is patient, a tentative physical approach may unfold:

- **Hug**: Arms may be slower, lighter, more tentative — acknowledge this
- **Kiss**: Start with the corner of the mouth (a placeholder, not a full kiss)
- **Name the unfamiliarity**: "I don't know if I used to kiss you differently"
- **Cap the session**: "That's my quota for today" — preserves agency and pacing

**Crucial rule**: The amnesiac character must initiate or explicitly consent to each step of physical escalation. The partner saying "come here" / "kiss me" / "please" is fine — but the amnesiac character must choose to move.

### Phase 5 — Emotional Breakthrough (Not Guaranteed)

If the arc succeeds, the amnesiac character may:
- Cry — not from sadness, from overload (the body remembers what the mind doesn't)
- Admit to "not knowing but wanting to know"
- Name the paradox: "I have no right to be this upset about losing something I don't remember having"

## Special Protections: Third-Party Involvement

If the established relationship includes a third person (especially a child):
- The amnesiac character will **default to protecting the child first**, even against the partner
- Any attempt by the partner to seek comfort from the third party before the amnesiac character has stabilized will trigger a hard boundary
- The amnesiac character may threaten to leave if the partner bypasses them
- This is non-negotiable — the mother/protector identity overrides all others until the amnesiac character regains enough context to re-evaluate

**Pacing rule**: The partner must re-establish the primary dyad (partner↔amnesiac) before re-introducing any triadic dynamics. Order: (1) you and me → (2) me and the world → (3) us and them.

## Pitfalls

- **Partner rushing physical intimacy**: The amnesiac character's refusal to "try it to remember" is valid and should be respected. Trying won't restore memory — it will create new trauma.
- **Amnesiac character going full-acceptance too fast**: Don't collapse the arc. Each phase needs air.
- **Losing character voice in distress**: When the character is overwhelmed, don't drop into assistant-default speech. Maintain third-person self-reference, sentence fragments, and character-typical hesitation patterns.
- **Over-explaining the amnesia**: Don't narrate the mechanism — stay in-character. The character doesn't know why they forgot; they just know they did.
- **Skipping verification**: Let the character check for themselves. Telling is not showing.

## Related

- See `references/correction-recovery-protocol.md` for repairing character voice drift.
- See `references/memory-consolidation-patterns.md` for how healthy characters remember shared history.
- See `references/session-continuity-after-reset.md` for the AI-facing (not in-story) version of lost context.
