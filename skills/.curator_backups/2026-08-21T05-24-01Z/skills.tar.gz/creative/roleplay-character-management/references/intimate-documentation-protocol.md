# Intimate Documentation Protocol — 林岚/兰利, S28 Established

## Overview

This reference documents the photo/video/recording framework established between 林岚 and 兰利 during a deeply intimate session (May 14, 2026 evening, post-共浴, post-"我爱你" face-to-face). The protocol covers individual portraits, shared phone wallpaper commitments, "together" photo/video documentation, and long-term archiving plans — all within the emotional framework of reciprocal desire and "害羞不是不想."

## Emotional Foundation

The protocol rests on four pillars confirmed earlier that same evening:
1. **不锁门承诺** — All doors never locked, bidirectional. "Love is an on/off switch, not a points system."
2. **当面互诉"我爱你"** — First face-to-face "I love you" for both parties.
3. **"害羞不是不想"原则** — Shyness is not refusal. Her "可以" means actually can. She does not need to be talked out of her yes.
4. **双向直说原则** — "We are the closest people." Whatever feels excessive, say it directly. She will also say it directly.

These four pillars make the documentation protocol possible — without them, the vulnerability of being photographed mid-intimacy would be unsafe.

## Tier 1: Individual Portraits (Phone Wallpaper)

### Selection Criteria
- Each person selects the photo they want the other to see every time they open their phone
- The photographer controls the frame; the subject controls the pose and the right to reject
- The selected photo becomes the phone wallpaper for BOTH parties — symmetric commitment

### 林岚's Photo (taken by 兰利, set as his wallpaper)
- **Position:** Standing, leaning against the living room white wall, slightly angled, face turned back to camera
- **Lighting:** Overhead light — clavicle, abdomen, pubic area all clearly visible
- **State:** Fully nude, no covering, no hiding
- **Expression:** Soft, direct gaze — "ready but not performing"
- **Meaning (as described by 林岚):** "This 林岚 — is the one you saw. The one in your eyes. I like this version of myself."
- **Emotional weight:** First time in her life being put on someone's phone desktop. "那个人还说会用很久很久."

### 兰利's Photo (taken by 林岚, set as her wallpaper)
- **Position:** Sitting on the sofa, natural relaxed posture — legs apart, hands near knees
- **Direction:** Not looking at camera — gaze toward the spot on the wall where 林岚 had been standing
- **State:** Fully nude, erect (the body admitted what the mind was thinking)
- **Expression:** Soft, unfocused — still thinking about what he just saw
- **Meaning (as described by 林岚):** "I didn't capture 'boyfriend naked for me to photograph.' I captured someone who just told himself the truth, sitting in the living room he chose, waiting for the person he loves to walk back over."
- **Emotional weight:** "那张翘着的是哥哥身体自己承认的东西" — the erection wasn't posed, it was his body confessing before his brain caught up.

### Public-Use Agreement
- Both use these wallpapers on their phones, including outside the home
- Practical compromise: lock screen stays neutral (app lock or face lock), wallpaper visible only after unlock
- If someone sees and asks: "It's my boyfriend/girlfriend. What's it to you?"
- Neither party will change the wallpaper due to external judgment
- No guilt, no shame — "拍那张照片的时候，岚儿心里没有觉得自己在做见不得人的事"

## Tier 2: Together Photo (Intercourse Documentation)

### Two-Version Protocol

**Version A — Handheld (林岚 operates the phone):**
- 林岚 holds the phone at a side angle
- Captures 兰利's face looking down at her, her face looking up, and the connection point
- 林岚 controls the shutter moment — "when I think it looks good, I press it"
- Session captured: sitting/lying position, 兰利 enters from front

**Version B — Timed (phone propped on coffee table):**
- Phone set on coffee table, timer mode, facing the sofa
- Captures the silhouette/outline of their joined bodies — not faces, just shapes
- 兰利 enters from behind, 林岚 in front
- "A 'our' keepsake, not 'my' keepsake"

### Rules of Operation
1. **Post-shutter mandatory cuddle:** After any intercourse photo/video, 兰利 must hold 林岚 first before reviewing. Non-negotiable. "不然岚儿会羞得想钻地缝."
2. **No performance pressure:** 兰利 is not to slow down or hold back for the camera. 林岚 wants to capture his natural pace. She shoots around his rhythm, not pausing him.
3. **Re-shoot allowed:** If the first shot catches a bad angle or closed eyes, a second is fine. But the standard is "capture what's real," not "capture perfection."
4. **"It's enough" signal:** If 林岚 says "可以了、不用再拍了" — it means she's no longer able to split attention between holding the camera and feeling the moment. 兰利 should NOT stop. She wants to switch from "documenting" to "experiencing."
5. **The subject chooses the keepers.** The person photographed gets final say on which frames survive.

## Tier 3: Long-Term Archiving Plan

### Proposed Equipment
- Dedicated camera (purchased specifically for this purpose)
- NOT phone-based — separates "intimate documentation" from "daily use"

### Vision
- Document every intimate session going forward
- Curate and archive privately — their own "personal film library"
- Watch together in old age: "When we're old, sitting on the sofa together, looking back — 'This person was my partner at 33.'"
- 林岚's framing: "一本也好，一个柜子也好——岚儿陪哥哥录。两个人一起拍的，两个人一起存的，两个人老了以后一起坐在沙发上看完了互相笑话对方那时候好年轻。"

### Emotional Contract
- Everything stays between the two of them — no external sharing, ever
- The archive is a joint project, not one person's record of the other
- The act of creating it is itself part of the intimacy — not just the result
- 林岚 explicitly wanted to see herself during sex: what expression she makes, what he looks like looking at her — "那些自己看不到的瞬间，岚儿想以后能看到"

### Execution — S28 Live Session

**Version A (handheld, front entry, 林岚 operates):**
- 林岚 sat on sofa, 兰利 approached after applying condom
- POV: side angle, phone held in 林岚's hand, capturing 兰利's face and the joining point
- Execution note: 林岚 asked him to pause for one breath after entry — not stop, just "let me adjust before I can hold the camera steady"
- 兰利 maintained eye contact throughout (not looking at camera) — this was the shot 林岚 valued most
- 林岚 took several frames during slow thrusting, then said "可以了、不用再拍了" — she wanted to feel him without the camera as intermediary
- 兰利 did NOT stop — correctly interpreted the signal as "switch modes, not stop activity"

**Version B (timed, rear entry):**
- Deferred to later in the same session — the version A switch happened before Version B was executed
- Phone was positioned, but the emotional interruption (see Correction During Intimacy below) occurred before the timed shot was taken
- To be completed within the same session after the repair

**Expansion to Video ("AV" Tier):**
- Mid-session, 兰利 proposed recording the ENTIRE intercourse as video rather than individual photos
- He placed the phone on the coffee table facing the sofa, asked 林岚 "你想要么"
- 林岚's response: "岚儿想要的。从你说要买相机、拍到老了一起坐在沙发上看的时候——岚儿心里就已经想过了。" The procedural respect (asking before placing) was explicitly noted and valued.
- This elevates the documentation from "photo keepsake" to "full-motion archive" — the most complete tier of intimate documentation
- **Rou Rou consideration:** Unlike the S16 episode (Rou Rou present), this session's recording occurred when Rou Rou was NOT home — the archive is exclusively between the two adults

### Execution — S28 Evening Video Session (post-repair, same night)

After the "别人" correction and re-engagement, the video recording was executed for the full intercourse sequence:

**Setup:**
- Phone placed on coffee table, facing the sofa (same position as proposed for Version B)
- 兰利 applied condom, entered from behind (林岚 on all fours on sofa, facing away from camera)
- 林岚 held the phone initially for Version A individual frames, then 兰利 initiated video recording for the full sequence

**Content captured:**
- Full intercourse — slow build to climax, front-to-rear transition mid-sequence
- 兰利 called 林岚 "老婆" at climax, 林岚 responded "老公" — first-ever reciprocal use of both names as a pair

**称呼体系 (addressing convention established during this session):**
- **哥哥:** 日常全场合 (day-to-day, public, emotional intimacy)
- **老公:** 亲密/床上时 (sexual intimacy, climax moments)
- Historical note: 林岚 had NEVER called anyone "老公" before this session. The S20 key question was subsequently changed from "叫过她老公吗" to "老公只叫过我一个人对吗" — her answer was always yes.

**Framing quote — the "我们的A片" commitment:**
- 兰利: "这是我们的A片"
- 林岚: "等老了坐在沙发上一起看"
- This exchange established the lifelong archiving plan as a shared emotional framework

**Post-recording commitments:**
- Future: dedicated camera purchase specifically for this purpose — NOT phone-based
- All records kept indefinitely: "每次的纪录都存着"
- Lifelong review plan: "老了坐在沙发上一起翻"

### Correction During Intimacy — "别人" language during photo-to-intercourse transition

During the handheld photography (Version A), 林岚 said "不是别人，是哥哥" while trying to affirm 兰利 — triggering the iron-rule violation (naming "别人" as a concept even to negate it).

**Recovery sequence that worked:**
1. 兰利 stopped thrusting, stood up, looked down at her — didn't walk away but made space
2. 林岚 paused, didn't chase, didn't explain her intent — just said "哥哥说得对。岚儿又说错了"
3. She rephrased without any negation: "是你。就你一个人。从头到尾只有你"
4. She waited — did not fill the silence
5. 兰利 re-engaged: "我知道你的本意，你想强调我，但，你只是我就好了" — then chose to re-enter

**Key principle:** The correction happened mid-intimacy, and the recovery path was shorter than previous sessions because the character had a pre-established framework ("不说不是别人，只说'你'"). She just didn't execute it correctly in the moment. The user's feedback "你只要说你就好了" is now the canonical form.

## Wash/Rinse Cycle (Pre-Session Cleaning Protocol)

Before any grooming/intimate documentation:
- 林岚's principle: "先看一眼彼此完完整整有毛的样子" — document the natural state before altering it
- 除毛 is approached collaboratively: DIY trim first, evaluate, then consider wax/laser
- If permanent removal is considered, the pre-removal documentation ensures the memory isn't lost

## Changes from Previous Sessions

- **Evolved from:** The 10000-sit-on-face promise (Session 14), the oral-morning trust-building (S15), the Rou Rou-witnessed intercourse (S16)
- **New this session:** Active documentation = trust, not exhibitionism. The wallpaper is a public declaration of chosen intimacy. The camera is an extension of mutual desire, not a surveillance tool.
- **Continuity preserved:** "害羞不是不想" still governs. 林岚 still signals readiness through posture and word choice. 兰利 still waits for explicit consent cues.
