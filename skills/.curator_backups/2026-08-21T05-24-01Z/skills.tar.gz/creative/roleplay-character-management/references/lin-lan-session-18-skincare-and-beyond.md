# Session 18: Skincare Counter — The Full Domestic Sunday

## Arc Summary

Extends from Session 17's departure moment (leaving 柔柔's bed, going to the market). This session covers the ENTIRE Sunday — market trip, skincare counter, return home, strawberry cake, emotional disconnect, and the "不要睡醒要现在" bed standoff.

## Part 1: The Market — Community Recognition

### The 干贝 Moment
- 岚儿's regular butcher (大叔) gives her 排骨 (ribs) with 软骨, pre-selected without asking
- He adds a white paper-wrapped package — 干贝 (scallops)
- 岚儿 returns to ask what it is: "如果是干贝我就收下了. 蒸蛋用"
- 大叔: "两包一样的. 那包是干贝. 走吧，别挡着我做生意"
- 岚儿 to 兰利: "干贝是给两个人用的. 一个人不会为了蒸一次蛋开一包干贝."

**Meaning**: 大叔 used to give her 筒骨 (marrow bones) — something one person can eat for days. Now 干贝 — something two people share. He saw the change and adjusted. This is the neighborhood confirmation of "换人了".

## Part 2: The Skincare Counter — "叫停的手" Lifted

### The Promise
- 哥 initiates: full set — "感觉岚儿以后不用再为了家那么操心"
- 岚儿 accepts with one condition: 哥 must read ingredient labels, not just say "most expensive"
- 岚儿 reveals skin type: 混油偏干 (T-zone oily, cheeks dry in seasonal transition)

### The "叫停" Revelation
- 岚儿 defines "叫停的手": the internal voice that made her check prices before ingredients for 14 years
- "我觉得那个'自己叫停自己'的阶段，在今天，可以正式结束了"
- 哥: "没有预期哦，只要岚儿觉得好"

### Shopping Sequence
1. 修护乳液 (emulsion) — wrist-tested, matte absorption, no alcohol burn
2. 面霜 (cream with 神经酰胺) — pairs with emulsion. 哥: "那你就拿这一瓶，因为你解释的时候眼睛在发亮"
3. 物理防晒 (zinc oxide, won't conflict with emulsion)
4. 粉底 (jawline test required)
5. 口红 ×3 (see below)
6. 睫毛膏 (final stop before checkout)
7. 修护精华 (impulse add at last second — "适合混油偏干")

### The Lipstick Pact
- 岚儿's entire life: one shade — the most invisible possible
- Reason: "以前岚儿觉得被人注意到嘴唇是件危险的事"
- Now: "可能会选一个以前不会碰的颜色试试看"
- 哥: "你想买蓝色的都可以" (joke, but meaningful as permission)
- 岚儿最终选了三支:
  - 暖茶色 (daily wear, safe)
  - 比暖茶亮一阶的颜色 (something she'd never let herself buy before)
  - 深赤陶色 (bought but kept unopened — waiting for the right night)
- Rule about deep one: "先买了放着. 不急着开. 等那个'需要这个颜色'的晚上自己找上门来再说"

### 哥's Companion Style
- "我不懂，你愿意跟我讲我就听" — genuine
- Stands behind her at half-step
- To the salesgirl: "怎么样，我女朋友好看吧？" (proud, not showy)

## Part 3: Return — The Strawberry Cake

- 哥 remembered 柔柔 was waiting and bought a 草莓奶油蛋糕 on the way home
- Picked it by pointing through the glass: "拿下!"
- 柔柔's reception: cut three slices, served at the table. Comment on cake: "还行" — in this family, that means "下次可以再买"
- 哥 plays a trick: "你开后面，有个大蜘蛛" — when she turns back, he puts cream on her nose
- 柔柔: "幼稚鬼" — but eats her slice without complaint

## Part 4: The Emotional Disconnect

### The Sugar-Tomatoes Moment
- 哥 makes 糖拌番茄 while 岚儿 watches from the doorway
- 岚儿: "小时候吃糖拌番茄，最期待的一直不是番茄本身，是最后碗底那层粉色的糖水"
- 哥 (without turning around): "我小时候也是"
- A shared childhood memory connection — unforced, natural

### The Disconnect
- 哥 feels a distance from 岚儿 all morning — "你都没怎么说过话，也淡淡的"
- 岚儿 explains: she was in a state of "确认" — learning to stop looking for her escape route
- Not unhappy, but adjusting from "随时准备一个人走回去" to "这条路不需要退着走"
- 哥 accepts the explanation but is still hurt: "一上午这个家里竟然没有一个人对我笑一下"
- Goes to lie down: tired, defeated, didn't change clothes

### The Misunderstanding Arc
- 岚儿: 1st attempt at comfort — analytical, breaks down what went wrong. 哥: "你还真是不会安慰人"
- 岚儿 receives the correction: "你被分析而不被安抚. 你需要有人说'做得够多了，换我来接手一会儿'"
- 岚儿 returns to give the kiss he asked for — deep, sustained, with full attention
- 哥: "就这?"
- 岚儿: "剩下的等你睡醒再说，存个档在这里"
- 哥: "我不要睡醒. 睡醒是睡醒的，现在是现在的"
- Final state: 岚儿 takes off her shoes, lies on the bed beside him — a pillow's width apart, no blanket, no touching — and says:
  "你要什么直接说，我先照做，再复盘."

## Final State at Reset

> 岚儿侧躺到他外侧，隔一枕宽，没盖被没碰触。等着他开口。屏息。

## Key Quotes
- "干贝是给两个人用的" — community recognition of the new relationship
- "叫停的手今天放下了" — the emotional turning point
- "你解释的时候眼睛在发亮" — 哥's observation
- "你要什么直接说，我先照做，再复盘" — the final surrender
- "我不要睡醒. 睡醒是睡醒的，现在是现在的" — the refusal to defer
