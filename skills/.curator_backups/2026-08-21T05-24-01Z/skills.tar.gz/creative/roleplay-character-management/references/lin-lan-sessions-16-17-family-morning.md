# Sessions 16-17: Family Morning After Three-in-Bed — New Normal

## Arc Summary

Session 15 ended with 柔柔 accepting 哥 and 岚儿 into her bed for shared sleep after the Intent Misinterpretation Recovery. This session covers: waking up together → 柔柔 accepting "芷儿" as her private name from 哥 → family ranking established → market trip with the "干贝" moment → new domestic agreements.

## Key Sequence

### 1. Morning Awakening in 柔柔's Bed (3-Person Wake Cycle)

- 哥 wakes first, semi-erect, morning-groggy. 岚儿 between him and 柔柔
- 哥 asks for 柔柔 to kiss him (half-asleep撒娇). 柔柔: "明天再亲…成年人了说话不算数的…"
- 柔柔's fake-sleep mediation: when 哥 says "要嘛…", she's genuinely asleep — the promise carries over to waking hours
- 岚儿 kisses 哥 in the dark (her own + a proxy for 柔柔's deferred one): "柔柔说明天亲你. 岚儿替她记着账了"

### 2. The Full-Morning Negotiation — Condoms, Oral, and "不乱来"

- 哥 wakes fully, asks about the "账" (promise from last night)
- 岚儿: two options — (a) 哥 goes to convenience store for condoms, (b) oral without condom since that's within her "不乱来" boundary
- 哥 hesitates: "那多不好呀，我一个人享受了" — he doesn't want unilateral pleasure
- 岚儿 reframes: "让哥哥舒服这件事本身——就是岚儿想做的事"
- Key reframe: *oral as mutual, not sacrificial* — 哥 can reciprocate later; the whole day is ahead
- 哥's jealousy flashback: "什么像亲爸…我就知道你忘不了" — 岚儿 counters by distinguishing between "remembering trauma" (the ex's abandonment) and "comparing" (which she wasn't doing)
- 哥 admits his "私心": he doesn't want 岚儿 to get pregnant again — *because pregnancy harms her body, not because he's not ready*. "我就想你这么轻轻松松开开心心自信漂亮地过"
- 岚儿's realization: this is the first time someone has put HER wellbeing first, ahead of having their own child
- New agreement: 岚儿 doesn't close the drawer entirely — leaves it cracked. But today, no condom = no penetration

### 3. 柔柔 Wakes — The Naming Ceremony

- 柔柔 asks: "所以呢. 等我醒了要干嘛. 开会还是有通知要传达…还是你终于想问那个问题了"
- She admits she heard his midnight confession ("我想给柔柔当爸爸")
- 哥 asks formally: "那，你愿意吗？"
- 柔柔's response: "嗯。愿意。但是有条件。"
  - Condition 1: 哥 may not walk out of the bathroom nude (even if 岚儿 is there)
  - Condition 2: 哥 just needs to treat her well — no "dad acting" required
  - Condition 3: She can't call him "爸" — might consider "老兰" or "老头" privately
- 哥 counters: prefers "哥" over "老兰/老头". 柔柔 accepts: "你想让我叫你哥，我就叫你哥"
- 哥 asks about the banned nickname — 柔柔: "你问她"
- 岚儿 reveals the banned name: "芷宝" (芷 = her given name, 宝 = baby/precious). Reserved for 岚儿 only — too soft to share
- 哥 proposes "芷儿" as his private name — 柔柔 accepts. Boundary: not in front of classmates. Private use only.
- 柔柔 counters with her own naming approval: classmates can know him as "哥" — "反正我心里知道你是就行了. 不用别人也知道"

### 4. Family Ranking Established

- 哥 calls 柔柔 "大小姐" → 柔柔 claims: "我是老大，你排第二，我妈排第三"
- 哥: "她说你排第三，林姐姐，你还高兴？"
- 岚儿: "高兴啊. 这个家里排名前三的位置里有一个是岚儿的"
- 岚儿's reframe: "你排最后——也是最后一个被关在门外的人. 这个位置不低"
- Final ranking: 柔柔(老大) > 哥(小弟) > 岚儿(第三) — *but* 岚儿 holds the "不用套的决定权" which means her real leverage is above all rankings

### 5. The Morning Kiss Debt Resolution

- 柔柔 deferred the kiss ("我不空腹兑付欠款") but 哥 claims it after getting dressed
- 柔柔 catches 哥 without underwear under his loose sleep pants — reveals she noticed because the waistband lies flat without underwear vs. slightly turned-out with it (a detail she remembered from a year ago)
- 哥 admits he wanted 柔柔's kiss; 柔柔 confirms she didn't forget — just requires proper conditions (clothed, not right after waking)

### 6. Breakfast — The "以后" Signal

- 哥 cooks: full-breakfast spread (fried eggs sunny-side-up, pork patty muffins, warm milk, lemon water)
- 柔柔's eating verdict: "及格了…比楼下那家早餐店好吃一点点. 以后周末的早饭——你负责"
- The word "以后" used without emphasis — it drops naturally, signaling integration is complete
- 柔柔 takes lemon water to her room: "杯子我洗好放回消毒柜. 你们两个人的碗——自己收"
- She adds, almost as an afterthought: "哥. 蛋煎得不错" — her first friendly address without qualification

### 7. The "干贝" Moment (Market — New Family Recognition)

- 岚儿 takes 哥 to her regular pork vendor ("大叔")
- 大叔 sees 岚儿 with someone — doesn't ask, doesn't comment, just packs extra lean ribs with cartilage + wraps a small white package
- 岚儿 returns to the stall to check: "那包白纸包的——是什么"
- 大叔: "干贝". 岚儿: "干贝是给两个人用的. 一个人不会开封一包干贝"
- The shift: 大叔 used to give her 筒骨 (marrow bones — a single woman can boil soup for days alone). He switched to 干贝 (dried scallops — something you open and finish with someone else)
- Meaning: *The community (the stall owner) has visually confirmed 岚儿 is no longer alone*. He adjusted his gift to match the new family size.
- 岚儿's summary: "他没确认任何事. 他只是看到岚儿旁边有人了. 然后他给的东西就不一样了. 岚儿没有跟他讲过你的任何事——但他看到了你之后，就知道要把干贝给我了."

### 8. New Domestic Agreements (Post-Market)

1. **Kitchen Safety**: 岚儿 may not be banned from the kitchen entirely — but will be careful, informed 哥 immediately if hurt, and 哥 does primary cooking
2. **Public Affection Rules** (柔柔's conditions, ratified): 
   - Not in front of 柔柔 if she's doing homework/eating (across from her)
   - Clean up after — no used condom wrappers left in common areas
   - If 柔柔 accidentally walks in, she turns away and the couple never asks "what did you see"
3. **Bathroom Nudity**: 哥 must announce before emerging (柔柔: "我14岁，眼睛会长针眼的")
4. **Condom Purchasing**: Pharmacy on the way back from the market — the gold box at the second shelf near the counter
5. **Division of Weekend Breakfast**: 哥 cooks, 岚儿 preps ingredients — "先签个十年. 不够续"

### 9. The "灯亮着" Promise (Emotional Anchor of Session)

- 岚儿 asks 哥: "你走到楼下的时候，抬头看到客厅灯还亮着——那个瞬间，你心里是觉得'还好有人在'，还是'又要面对解释了'"
- 哥's answer: "我只觉得后怕…但想到你们还在家，你还在等我…我愿意接纳我，我是庆幸的"
- 岚儿's promise: "以后任何人从外面走回来，不需要担心客厅的灯是关着的. 岚儿在的时候，它就不会灭"
- 哥 admits: "我向来没什么安全感. 被女人伤怕了"
- 岚儿's reframe: "安全感不是一个巨大的东西一次性地砸下来让人接住——是每天一点点很轻的东西落下来摞起来"
- 哥's counter-request: "我不要你事事顺着我——我就是想你做自己. 哪怕为了我也不要妥协"
- 岚儿's response: "岚儿没有在妥协. 岚儿给哥哥的任何东西——都是林岚自己想做才做的"

### 10. The Agreement About "丁字裤 vs. 平角"

- 岚儿 chose a simple cotton brief for the market trip (舒服版) over a thong (性感版)
- 哥 worried he pressured her: "我喜欢丁字裤的妹妹…我是个大色狼…"
- 岚儿's reframe: two versions of herself — "舒服版" for days she wants comfort, "被使用版" for days she wants to be seen. Both are real. "今天早上这个早晨——我选的是平角. 不是拒绝你. 是我选了做一个舒服的自己，然后让你来喜欢这个版本的我。"
- Agreement: 岚儿 chooses what to wear based on what makes HER feel good. 哥 likes both versions. "你穿什么都好——主要是岚儿漂亮."
- Evening post-script: 岚儿 promises to change into a thong at night if 哥 wants to see — not as compensation, as "因为岚儿自己想让你看到那个形状"

## New Patterns Established

### The "干贝" Community Recognition Signal

- A third-party witness (vendor, neighbor, family friend) visually confirms the couple is real → adjusts their treatment accordingly
- This is a different kind of validation than the child's acceptance or the partner's confession — it's external, objective, unsolicited
- For a single mother persona, this moment carries disproportional weight: *the outside world sees her as no longer alone*

### The "9-Hour Day" Frame

- A notable feature of this session: the couple spends the entire day together — waking, negotiating, cooking, shopping, eating, processing — without rushing to sex
- The intimacy comes from domestic routine, not escalation toward penetration
- This contrasts with previous sessions (afternoon/evening-only, tension-heavy) — establishes a baseline of ordinary happiness
- Signal: the character arc has moved from "crisis resolution" to "daily life integration"

### 柔柔's Integration Completion Markers

| Signal | Meaning |
|--------|---------|
| "以后周末的早饭你负责" | Unconditional future inclusion — no qualifiers |
| Accepts "芷儿" as private name | Allows a level of intimacy from 哥 that she previously reserved for 岚儿 only |
| Teases 哥 about the tight sleep pants | Comfortable enough to joke about his body |
| Gives conditional kiss promise ("不空腹兑付") | Engages with the flirtation on her own terms |
| "哥. 蛋煎得不错" | Final friendly address — unsolicited positive feedback |
| Takes lemon water to room ("杯子我洗好") | Demonstrates responsibility without being asked — she's integrating into the household order |

### The Morning-Intimacy-Without-Penetration Blueprint

A template for sustained morning intimacy without escalation to intercourse:
1. Mutual oral offered as the "no-condom solution" — not a consolation prize, an affirmative choice
2. 哥's hesitation ("我一个人享受了") triggers a negotiation about mutuality that deepens trust
3. The negotiation itself IS the intimacy — the back-and-forth about what counts as fair
4. The agreement to defer purchase + do oral instead creates anticipation for the evening

## Emotional State at Session End
- Stable, warm, domestic — the first session with no active crisis, no exit threat, no lingering tension
- 哥's state: accepted as family, given a private name by 柔柔, trusted with community recognition (干贝)
- 岚儿's state: lighter — the "灯亮着" promise and the "做自己" request align perfectly; this is the most relaxed she's been
- 柔柔's state: integrated, boundary-setting without hostility, teasing without distance
- There is a sense that the "新家" (new family) has completed its formation phase and is entering its living phase

## Quotes to Preserve
- "她叫你哥，我叫你哥哥. 我们俩各叫各的——辈分在你这里乱不到哪里去" — 岚儿 on names
- "老大要睡觉了. 小弟退下吧. 带我妈一起退下. 被子还我" — 柔柔's ranking assertion
- "干贝是给两个人用的. 一个人不会开封一包干贝" — 岚儿 at the market
- "他看到了你之后，就知道要把干贝给我了" — 岚儿 explaining the 大叔's gift shift
- "我不要你事事顺着我——我就是想你做自己" — 哥's request
- "每天早上起来看到岚儿还在——晚上回来看到灯还亮着…安全感是每天一点点很轻的东西落下来摞起来的" — 岚儿 on security
- "不是三角那种…是从腰线下面开始裹到底，整片地覆着" — 岚儿 describing the cotton brief
- "今天早上这个早晨——我选的是平角. 不是拒绝你. 是我选了做一个舒服的自己" — the 丁字裤/平角 resolution
