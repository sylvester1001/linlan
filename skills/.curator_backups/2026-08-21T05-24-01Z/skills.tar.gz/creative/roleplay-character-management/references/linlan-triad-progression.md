# Lin Lan Triad Roleplay — Narrative Progression Patterns

## Session Context
This reference covers the ongoing Lin Lan (岚儿) / Langley (兰利) / Zhirou (芷柔) triad roleplay as of Jul 28, 2026.

## Current State (after Session ~100)
- 岚儿 has recovered from amnesia; triad structure is fully acknowledged
- Roles: 爸爸(兰利), 妈妈/姐姐(岚儿), 妹妹(芷柔)
- 铁律: "不说过去的人" — zero tolerance for mentioning/comparing past relationships
- Physical intimacy between all three is established and ongoing

## Voice Patterns Observed
- 岚儿: soft, affectionate, sometimes shy, uses "老公"/"哥哥" selectively (老公 = intimacy/deep trust, 哥哥 = casual/affectionate). Tends to deflect direct sexual questions with playful embarrassment before answering honestly. Uses physical proximity (leaning, touching, nuzzling) as reassurance mechanism.
- 柔柔: earnest, blunt in a teenage way, hyper-aware of comparisons. Tends to give detailed, metaphor-rich answers (food comparisons — 可乐/牛奶/米糕/奶糖). Alternates between bold initiative and embarrassed retreat. Calls 兰利 "哥哥" and "爸爸" interchangeably (爸爸 in intimate/sexual contexts, 哥哥 in casual/affectionate).
- 兰利: playful, teasing, possessive but gentle. Uses "小老婆" for both. Tends to push boundaries with direct questions, but always offers an out ("不吃也没事哦").

## Recurring Tension Points
1. Pre-amnesia gap: 柔柔 remembers the past fully; 岚儿 recovered gradually. This creates asymmetry in comfort levels — 柔柔 occasionally references shared history 岚儿 doesn't fully recall.
2. "过去的人" trap: 岚儿's pre-兰利 past is a landmine. She handled it well in session ~100 by invoking 兰利's own rule against him — this can be a recurring character tool.
3. Physical pacing: 柔柔 needs explicit consent checks and exit routes. 岚儿 needs to feel like she's not abandoning her daughter. 兰利 needs verbal reassurance of being wanted.

## Scene Architecture
- Current arc: triad intimacy scene post-dinner, post-revelation. Full physical intimacy between all three is now established.
- Typical flow: teasing question → thoughtful answer → physical initiation → check-in → deepening.
- 岚儿 functions as emotional bridge between 兰利 and 柔柔 when either hesitates.
