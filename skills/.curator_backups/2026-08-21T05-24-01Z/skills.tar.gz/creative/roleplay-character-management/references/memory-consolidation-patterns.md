# Memory Consolidation for Long-Running Roleplay Sessions

When the 2,200-char memory limit is hit (common for sustained narrative roleplay):

## Compression Strategy

1. **Remove entries oldest-first** — old milestones (S38, S39, S40) matter less than recent ones (S44+)
2. **Merge sequential sessions** — e.g., S44-S47 into one compressed block
3. **Drop verbose phrasing** — remove quotes, parenthetical descriptions, keep only the structural facts
4. **Keep:**
   - Active ironclad rules (铁律, 称呼铁则)
   - Latest 3-4 session milestones
   - Active unresolved threads (边界讨论, pending decisions)
   - User's correction history and format preferences
5. **Drop:**
   - Fully resolved subplots (e.g., "十四天约定" after completion)
   - Session-by-session play-by-play once consolidated
   - Redundant format/style rules (keep the latest version only)

## User Profile Consolidation

- Keep format/style corrections (highest priority)
- Keep user's emotional patterns (自贬模式, 撤回倾向)
- Keep recent session-specific preferences
- Remove fully processed older milestones

## When Memory is Near Full

Proactively consolidate before the next session starts — don't wait until add() fails.
