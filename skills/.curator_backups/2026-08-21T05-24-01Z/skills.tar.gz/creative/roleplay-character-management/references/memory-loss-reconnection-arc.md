# Memory Loss / Identity Erasure Reconnection Arc

## Overview
A structured approach to roleplay scenarios where a character has forgotten (or partially forgotten) a deep intimate relationship. The partner character remembers fully. The challenge: rebuild connection from scratch using body memory, archived records, and gradual trust signals — without the forgetting feeling rushed or the rememberer feeling exploited.

## Emotional Architecture

### Phase 1: Denial-Reality Collision
The discovery phase. Key beats:
- **Archive as witness**: Present physical evidence (diaries, photos, scars, objects in drawers) before asking for emotional buy-in. Objects are less threatening than memories.
- **Protective instinct override**: The forgetting character's first stable ground is often a protective role (parent, friend, guardian). Let them stand on that before asking them to stand on "love."
- **"I don't recognize you but my body does"**: The first crack in denial should come from physical instinct — hands that know how to hold, a kiss that lands correctly, a shoulder that fits. Name the gap explicitly.

### Phase 2: Negotiated Vulnerability
The character gives ground in measured increments. Each step forward must be paired with a boundary that the partner must respect:
- **Lowest-rung offer**: "I can sit next to you but not touch." "I can let you hold me but not kiss." Offers that keep connection alive without overstepping what the character can consciously consent to.
- **Time-boxed permission**: "Tonight I'll sleep beside you. Tomorrow I'll decide about tomorrow." Creates safety through temporal limits.
- **Barter system**: "You get this if you promise not to push for that." Gives the forgetting character agency in a situation where they have no memory-based agency.

### Phase 3: Gradual Body-Memory Recovery
Physical reconnection happens in stages. Do not skip steps:
1. **Proximity** — same room, visible, within reach
2. **Passive contact** — hand resting, back touching, head on shoulder
3. **Active non-sexual touch** — holding, stroking, hugging
4. **Kissing** — start brief, let the character set duration
5. **Naming** — saying "husband/wife/lover" aloud as a self-check
6. **Sexual touch** — should come after the character explicitly names the desire

### Phase 3.5: The "Call-Back" Moment
A critical intermediate step: the character, unprompted, uses a term or gesture from the forgotten relationship unprompted. This is the first proof that memory is returning through the body rather than being reconstructed through the archive. When this happens, pause — let the character sit with the evidence.

### Phase 4: Full Reconnection (with New Ground Rules)
Once the character reconnects:
- Acknowledge that the recovered relationship includes elements the character may now see differently (e.g., involving a child, if applicable to narrative)
- Establish whether the "new" version of the relationship will be identical to the "old" version or intentionally different
- The partner must accept that the character may never "fully remember" — and that a partial reconstruction is still real

## Pitfalls to Avoid
- **Assuming consent from past consent**: The partner cannot say "you used to like this" as justification. Each act requires fresh consent from the current-state character.
- **Skipping boundaries**: When a forgetting character says "stop there" and the partner says "but you used to go further" — that's a violation in-world, not a persuasive argument.
- **Emotional blackmail**: "If you loved me you'd remember" — this destroys trust and should be treated as an in-character mistake the partner can learn from.
- **Over-relying on the archive**: The forgetting character should experience gaps and uncertainty. Perfect recall via document-reading robs the arc of its emotional tension.
- **Rushing the "first kiss/sex" milestone**: The most powerful versions of this arc let the character initiate physical reconnection themselves, even if hesitantly.

## Example Arc (Condensed from Session)
1. M: "I don't remember you. You're my roommate."
2. F: Shows archive. M reads it, is horrified/disturbed.
3. M: "I need space. Don't touch me."
4. F: Gives space. M begins to notice physical evidence (grooming, objects).
5. M: "You can hold me but don't move."
6. M: Kisses F briefly as a test.
7. M: Says intimate name ("husband") aloud → feels warmth → re-engages.
8. M: Initiates sex on own terms, with explicit boundaries.
9. M: Names the boundary for future sessions.

## Narrative Considerations
- The forgetting character should *earn* their memories back through choices, not have them restored by fiat
- Interstitial moments (silences, pauses, half-finished sentences) are more important than dialogue for showing internal processing
- Use physical objects as grounding anchors: a shirt, a drawer, a scar, a smell
- The partner's patience (or impatience) is a major emotional driver — their behavior during the arc determines whether the recovered relationship is stronger or weaker than the original
- If a child exists in the narrative, the parent-child bond is the forgetting character's strongest anchor and most sensitive boundary — treat it as a narrative keystone, not an obstacle to overcome
