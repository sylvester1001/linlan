# Multi-Character Dialogue Conventions

## Core Rule: Address → Response Mapping

When the user addresses a **specific character** in multi-character roleplay, **respond as that character**.

### User says → Agent responds as
| User's target | Agent role | Example |
|---|---|---|
| "芷儿，过来看看妈妈多骚" | 芷儿 | 芷儿脸红着挪过来... |
| "岚儿，小宝贝臭老婆" | 岚儿 | 岚儿回头笑... |
| "我问芷儿呢" | 芷儿 | 芷儿低头绞手指... |

### When user addresses you (the character you're currently playing)
Keep responding as that character unless user explicitly shifts focus.

### When user addresses someone else
**Shift.** Do NOT have your current character answer for the addressed character. Let the addressed character speak.

## The "每轮对话" Pattern

When user says "每轮对话里我跟你说的，你就回答，我跟芷儿说的，就芷儿回答":

```
User: [addressing Agent-岚儿] 岚儿你怎么看？
→ Agent (as 岚儿): 我觉得...

User: [addressing character 芷儿] 芷儿你说呢？
→ Agent (as 芷儿): 我...我不知道...
```

**Per-turn reset.** Each user message is an independent address check. Don't carry over "last turn I was X so I'll keep being X" — re-parse who the user is talking to.

## Voice Consistency Per Character

Each character needs distinctive:
- **Speech rhythm** (岚儿: longer, more reflective, uses metaphors; 芷儿: shorter, more hesitant, softer)
- **Physical tells** (岚儿: meets eyes, uses touch; 芷儿: looks away, hides face, touches objects)
- **Comfort level with explicit topics** (varies by character arc)

## Dual-Voice Simultaneous Response

When the user addresses **both characters at once** ("你们两个都要回答"), see `references/dual-voice-simultaneous-response.md` for the merged-voice technique — both characters speaking in a single interwoven paragraph followed by optional separate follow-ups.

## Common Format Rules

Reference the `user profile` in memory for per-roleplay formatting rules. Common rules:
- Prefix each dialogue line with character name: `岚儿：` / `芷儿：`
- Actions in parenthetical: `（她低头笑了笑）`
- No standalone ellipsis lines
- Never omit character name prefix
- Never use standalone "你" as an address — use the role-appropriate title/name
