# Multi-File Archive Restoration

**Context**: During the May 2026 session lifecycle, the user maintains a detailed narrative archive at `~/.hermes/memory/linlan-archive.md` and occasionally provides standalone record files (`record_N.md`) for individual scenes.

## When to Use This Protocol

Standard single-archive restoration (see `session-continuity-after-reset.md`) covers the common case. Use this protocol when:

1. The user provides **both** an archive **and** a standalone record file
2. The archive covers multiple past sessions with compressed summaries
3. The record file covers the **most recent** session in full transcript detail

## Full Restoration Checklist (Known Variants)

The agent may need to restore from more than just the archive + record. In practice, up to **five source types** may be needed:

| Source | When Needed |
|--------|-------------|
| **Archive** (`~/.hermes/memory/linlan-archive.md`) | Always — relationship history, iron laws, all past sessions |
| **Memory** (`memory` target) | Always — already loaded per-session; contains current rules, latest frame |
| **User profile** (`user` target) | Always — format redlines, naming iron laws, interaction mode preferences |
| **Character reference** (e.g., `references/lin-lan.md`) | After long gaps — restores voice signature, physical descriptors, escalation ladder, exact don't-say phrases |
| **Format rules** (e.g., `references/linlan-format-rules.md`) | After long gaps — restores bracket-paragraph separation, ellipsis prohibition, single-action-per-bracket |
| **Session-specific reference** (e.g., `references/s39-travel-planning-*.md`) | When the user references a specific recent event without providing the full record — confirm details from the compressed reference |

**When each is needed**: If the user says "找回之前的状态" (restore previous state) after a long absence or reset, load ALL sources. If the user provides specific filenames, prioritize those.

## Merging Order

1. **Memory + User profile first** — Already loaded in system; scan for iron laws, format redlines, and the latest frame description
2. **Archive second** — Read the full archive to establish relationship history, emotional timeline, iron laws, and character evolution. Watch for truncation (`truncated: true` in read_file response)
3. **Character reference third** — Read the character voice reference to recalibrate tone, physical descriptors, and the exact escalation ladder
4. **Format rules fourth** — Confirm bracket format rules, ellipsis prohibition
5. **Record/Session reference last** — Read the most recent scene's exact emotional beats and dialogue. This always takes priority for the current emotional state (it is more recent than the archive's last entry)
6. **Resolve conflicts**: If the archive says "character was in state X" but the record/reference shows them in state Y → trust the more recent source

## Cross-Reference Step

Before the first character response, **verify the iron laws across all sources**. Three sources (memory, archive, character reference) may each contain iron laws — always take the **most restrictive version** and consolidate mentally:

- Memory may contain S38-S50 rules (oral-only, naming, voice style)
- Archive may contain foundational铁律 (no past reference, no comparison)
- Character reference may contain don't-say phrases (specific out-of-character lines)
- Format rules contain paragraph structure rules

**Priority rule**: If a restriction appears in even ONE source, it applies. Don't assume the absence of a restriction in one source means it's been rescinded.

## Memory Restoration Strategy

| What to restore → | Source |
|-------------------|--------|
| Relationship history | Archive |
| Iron laws / rules | Archive |
| Current scene state | Record |
| Emotional tone for current scene | Record (primary), Archive (background) |
| Character voice calibration | Record (primary, for exact cadence) |
| Setting / location | Archive (confirm with record) |

## Pitfall: Archive Truncation

When using `read_file()` on the archive, always check `"truncated": true` in the response. If truncated, call `read_file()` again with `offset=N` to continue reading. Archives can be very long (see e.g. `linlan-archive.md` at 1353+ lines). Read in increments of 500 lines, then ask if user wants more.

### Sub-pitfall: Path Discovery

The user may say "还有 ~/.hermes/memory/archive" or "读一下 archive" but the exact path they name may not exist. The `read_file()` error response includes a `"Similar paths: [...]"` field. Check that field: the real archive is often `~/.hermes/memory/linlan-archive.md` even when the user calls it just "archive". Do not loop trying the wrong path -- read the suggested similar path immediately and confirm with the user.

When memory is at capacity and `memory()` calls fail with `same_tool_failure_warning`, this file-based archive becomes the primary data source. Read it fully and rely on the `current_entries` from the memory error messages rather than retrying failed memory writes.

## Pitfall: User Explicitly Checks "Archive" Separately

The user distinguishes between three memory stores: (1) `memory(target='user')` — user profile, (2) `memory(target='memory')` — personal notes, (3) `~/.hermes/memory/linlan-archive.md` — narrative archive file. If you only read the memory tool entries and skip the file-based archive, the user will ask "archive也看了么？" Always do BOTH: read from both memory tool targets AND the file-based archive.

## Pitfall: Memory Full → Read via Diagnostic Failures

The `memory` tool has no native "list" or "read" action — only "add", "replace", and "remove". When memory is at capacity (near the ~1,375/2,200 char limit), `memory(action='add', ...)` will fail with an error that contains `"current_entries"` — listing the existing stored entries. Use this as a diagnostic read technique: attempt an add, and if it fails, extract the current entries from the error message. Do NOT get stuck in a retry loop — stop after the first failure and switch strategies (either consolidate old entries or read the file-based archive instead).

## Pitfall: Getting Stuck in a Memory Tool Loop

If `memory(action='add', ...)` fails repeatedly because the target is full, the tool system may generate a `same_tool_failure_warning`. When this happens:
1. Stop all `memory` tool calls immediately
2. If you need to read: use the error responses you already received (they contain current entries)
3. If you need to write: consolidate/remove old entries first, or use `replace` instead of `add`
4. Switch to reading the file-based archive (`~/.hermes/memory/linlan-archive.md`) as an alternative data source

## Pitfall: Voice Recalibration

After reading both sources, read the last 15-20 lines of the record **immediately before your first character response** to recalibrate tone, cadence, and formatting. The most common failure after restoration is using your default assistant voice instead of the character's established voice.
