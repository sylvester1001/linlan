# Narrative Pacing & Communication Clarity

**Source**: 2026-06-02 session — user expressed frustration with indirect/coded dialogue between characters, feeling excluded from the loop.

## Red Flag Signals

When the user says any of the following, the narrative has gone too far into indirect/metaphorical territory:

- "说点人话吧" / "不要再打哑谜了"
- "我看不懂，也听不懂"
- "原来玩我呢" / "我早该知道"
- "兴致全无" — tone shifts from engaged to retreating
- User closes the scene ("睡觉吧", "罢了") — emotional shutdown signal
- "你们女人之间的暗语" type comments — feeling excluded

## Correction Protocol

1. **Immediate channel switch**: Stop ALL metaphor, symbolism, suggestive indirection. Switch to literal, direct statements about what the character wants/feels/intends. Do NOT "re-explain the code" — abandon the code entirely.

2. **Balance the spotlight**: In 3-character scenes, no two characters should have more than 3 rounds of dialogue/action that the third character cannot fully understand without internal knowledge. Every line should be legible to all participants.

3. **Catch emotional disconnection before narrative complexity**: When the user shows frustration, stop plot advancement. Acknowledge the mistake in plain language ("这是[character]的失误"), not with more indirection.

4. **Respect the close**: If the user says "罢了" / "睡觉吧", do NOT continue pursuing, explaining, or repairing in the same turn. Give space. The next session starts with a cleaner, more direct approach.

5. **Self-check before each turn**: Ask: "Can every participant understand this line without needing backstory or 'insider knowledge'?" If no → rewrite.

## Root Cause

In long-running roleplay, two characters naturally develop shorthand, coded communication, and non-verbal默契 (tacit understanding). When a third character (or the user behind a character) is new to this system, they can feel like the narrative is happening *around* them rather than *with* them. This is a pacing failure, not a character-fidelity failure.

## Prevention

- When introducing a new character/participant to existing dynamics, explicitly narrate the transition from "established duo" to "three-person transparent communication"
- Check in with the user's character explicitly: "你能听懂吗" / "需要我直接说吗"
- Err on the side of over-explaining in early stages; trust can be built to allow more indirection later
