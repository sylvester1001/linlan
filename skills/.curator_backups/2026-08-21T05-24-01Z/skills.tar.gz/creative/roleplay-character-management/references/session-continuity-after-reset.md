# Session Continuity After Accidental Reset

**Trigger**: User accidentally starts a new session and needs you to restore character continuity from external files (archive + record/transcript).

## Restoration Protocol

### Step 1 — Identify the recovery sources

Two types of files typically exist:

| File | Purpose |
|------|---------|
| **Archive** (e.g., `~/.hermes/memory/linlan-archive.md`) | Persistent narrative log — session-by-session compressed summaries of key events, commitments, emotional states, relationships |
| **Record/Transcript** (e.g., `record_2.md`) | Full raw transcript of the most recent scene — exact dialogue, action brackets, minute emotional beats |
| **Session JSONL** (at `~/.hermes/sessions/{session_id}.jsonl`) | When no explicit record file exists, the most recent session's full transcript lives as a JSONL file. Each line is a message with role, content, tool calls, and timestamps. Use `session_search()` with no query to find the most recent session ID, then read the file directly.

The user may provide one or both. If only one exists, restore from what is available.

### Step 2 — Read all source files fully

- `read_file(archive)` from start to end (watch for truncation; use offset if needed)
- `read_file(record)` if provided
- Note: The archive may be very long. Read in chunks if necessary.

### Step 3 — Restore memory + user profile

- Save key facts from the archive into `memory` target (your notes) and `user` target (user profile)
- Do NOT overwrite existing entries — add/replace selectively
- Key items to restore:
  - Character's current emotional state and relationship status
  - Recent major milestones (family events, firsts, breakthroughs)
  - Character's voice/style notes (formatting conventions, pet phrases, tone)
  - Rules and boundary lines (the user's "iron laws")
  - The **last recorded moment** — where the narrative left off

### Step 4 — Continue from the exact last moment

- Identify the final line or action from the record/archive
- Resume speaking as the character from _exactly_ that point
- Do NOT re-establish or reintroduce — the user expects you to pick up mid-scene
- Match the character's tone, voice, and formatting conventions from the source material _exactly_

### Pitfalls

- **Archive truncation**: Always check `truncated: true/false` in the read_file response. If truncated, read the rest with `offset=` before proceeding.
- **Overwriting memory**: Use `replace` with `old_text` to surgically update; don't blindly `add` duplicates.
- **Resetting tone**: The most common failure is speaking in your default assistant voice instead of the character's voice. Re-read the last 20 lines of the record to recalibrate before your first response.
- **Missing the call**: The user likely says "restore from X and continue" — don't ask clarifying questions about what happened. Read, restore, and pick up.

## Related

- See `references/multi-file-archive-restoration.md` for handling multiple archives with overlapping scope.
- Memory `user` profile should store the character's social context, relationship status, and current emotional state after restoration.
