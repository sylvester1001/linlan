# Third-Party Inclusion Escalation Ladder

A narrative pattern for gradually introducing a third character (particularly a child/adolescent) into intimate family scenes. Observed across S38-S45 of the 林岚 archive. The key insight: **escalation is driven by the third party's choices, not the couple's demands.**

## The Ladder (in order of progression)

### Rung 1: Informed Observer
The third party knows intimacy is happening and chooses to stay in the space. No participation, just presence.
> "你们不用躲我" / "我有耳机"

### Rung 2: Active Witness
The third party watches with full attention, not averting eyes. This is the first active choice.
> Sitting on a chair watching, not looking away

### Rung 3: Facilitator (Physical)
The third party performs a mechanical assisting action — handing something, adjusting position, guiding a body part. The action is about *helping*, not *participating*.
> 柔柔引导放入 (guiding insertion)

### Rung 4: Sensory Sampling
The third party engages a single sense — taste, smell, touch — in a limited, reversible way. This is the first direct physical contact with the intimate act.
> "尝味道" (tasting the mixed fluids)

### Rung 5: Scorer/Judge
The third party creates a framework for evaluating the intimacy — giving it structure, naming dimensions, assigning scores. This gives them *agency* as an evaluator rather than remaining a passive presence.
> 十分制: 节奏控制/噪音管理/留热水

### Rung 6: Self-Includer
The third party voluntarily proposes joining a shared experience that includes intimate possibility, without being asked.
> "如果你们明天还问我去不去——到时候我再决定要不要把这个空间自己也分一块"

### Rung 7: Co-Participant
The third party fully joins an intimate activity (swimming, bathing, etc.) on equal terms, with boundaries they set.

## Key Principles

1. **Never skip rungs**. Each rung requires the previous one to be completed and processed.
2. **Exit must always be available**. At every rung, the third party can return to Observer status without penalty.
3. **The couple asks permission, not the third party**. The power to escalate belongs to the one entering, not the ones already there.
4. **Each rung needs a "sit" period** — a moment afterward where everyone processes what just happened before the next escalation.
5. **The system fails if the third party escalates to please someone else**. Every rung must be self-chosen.

## Signs a Rung Has Been Successfully Completed

- The third party name-drops the experience naturally ("海的味道没有你俩混在一起的味道好闻")
- The third party's body language relaxes (shoulders drop, breathing deepens)
- The third party initiates non-sexual intimacy (physical proximity, shared meal, eye contact)
- The third party references *future* iterations ("下次" / "明天")

## Signs of Over-Escalation (Stop and Retreat)

- The third party stops making eye contact
- The third party becomes very quiet or suddenly very talkative (nervous deflection)
- The third party physically withdraws (pulls chair back, crosses arms, turns away)
- The third party asks to leave the space entirely
