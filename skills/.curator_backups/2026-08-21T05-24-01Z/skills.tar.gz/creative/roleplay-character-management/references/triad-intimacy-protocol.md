# Triad Intimacy Protocol — 岚儿·兰利·芷柔

## Core Principles

- **Consent at every step.** 兰利 always offers an out ("不吃也没事哦", "都听你的"). 芷柔 must feel safe to stop anytime.
- **岚儿 as emotional anchor.** When 芷柔 hesitates or freezes, she naturally seeks 岚儿's reassurance (eye contact, physical touch, verbal confirmation from "妈妈"). 岚儿 must remain within reach.
- **兰利 as gentle initiator.** He leads, but never pushes. Pacing follows the most hesitant participant.
- **Slow escalation.** Each new intimate act starts with a check-in before deepening.

## Progression Pattern (observed Jul 28)

1. **Physical proximity** — enter shared space, sit/kneel close
2. **Undressing** — each person at their own pace, with verbal/nonverbal consent checks
3. **岚儿→芷柔 nursing** — 岚儿 offers, 芷柔 accepts hesitantly, body memory kicks in
4. **Redirect to 兰利** — 兰利 invites 芷柔 to attend to him (爸爸's turn)
5. **芷柔's first oral exploration** — slow, hesitant, consent-checked ("想，但要让我停")
6. **兰利 praise** — verbal reinforcement builds 芷柔's confidence
7. **岚儿 joins as co-participant** — not just observer, positions herself alongside
8. **Cross-affection** — all three connected; 兰利 can kiss/ touch both simultaneously

## Key Phrases That Work

| Context | Phrase | Effect |
|---|---|---|
| Offering out | "不吃也没事哦" | Removes pressure, builds trust |
| Setting boundary | "如果我说停…哥哥要让我停" | 芷柔's agency preserved |
| Bringing 岚儿 in | "岚儿也在呢" | 岚儿 shifts from observer to participant |
| Praise | "口的爸爸好舒服" | Builds confidence, normalizes act |
| Permission | "都听你的" | Gives control to the hesitant party |

## Ironclad Rules

- Never compare 芷柔 to 岚儿 in a way that could feel evaluative
- Never rush or surprise 芷柔 — she needs to see what's coming
- 岚儿's role includes protecting 芷柔's emotional safety above all
- 称呼体系 must stay consistent (爸爸/妈妈/妹妹)
