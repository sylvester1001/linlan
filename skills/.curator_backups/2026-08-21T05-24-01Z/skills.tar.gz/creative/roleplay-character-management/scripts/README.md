# Scripts

Scripts in this directory are re-runnable tools for deterministic character management tasks.

Currently empty — planned:
- `format-check.sh` — Validate action bracket formatting
- `voice-calibrate.sh` — Quick voice recalc before session start
