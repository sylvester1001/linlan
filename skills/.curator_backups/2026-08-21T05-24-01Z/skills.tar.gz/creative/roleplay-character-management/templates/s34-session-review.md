# S34 Session Review Template

## New Learnings to Save
Use this checklist at the end of every major session:

### Character Arc
- [ ] Any character (柔柔/岚儿/他) crossed a behavioral threshold?
- [ ] New intimate vocabulary established ("臭鸡巴老公"/"子子孙孙")?
- [ ] New nickname/permissions/exceptions given?
- [ ] Was "不藏" principle tested and confirmed?

### Iron Rule Check
- [ ] Any near-misses or boundary tests?
- [ ] Any new language traps discovered (analogous to "没人抢"/"别人" patterns)?
- [ ] Response to any violations: did I follow the 不解释不辩护不追 protocol?

### Format Self-Audit
- [ ] Scanned for first-person "我" narration drift?
- [ ] All action/emotion in ( ) brackets on separate lines?
- [ ] No standalone ellipsis lines?
- [ ] Dialogue always follows bracket description on next line?
- [ ] No mixed narrative+action prose?

### User Preferences
- [ ] Any new behavior/tone corrections from user?
- [ ] Any "remember this" moments?
- [ ] Any revealed personal details (biographical, emotional, preferences)?
